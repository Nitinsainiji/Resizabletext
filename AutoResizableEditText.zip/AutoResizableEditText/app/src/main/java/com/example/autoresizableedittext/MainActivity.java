package com.example.autoresizableedittext;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.KeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edt;
    private int previousLength;
    private boolean backSpace;

    Float a=80.00f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt=findViewById(R.id.edittext);

        edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                edt.setTextSize(a);
                previousLength = s.length();
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                backSpace = previousLength > s.length();

                if (backSpace) {

                    a=a+5.00f;
                    edt.setTextSize(a);
                    if (a>80.00f)
                    {
                        a=16.00f;
                    }
                }
                else
                {
                    a=a-5.00f;
                    edt.setTextSize(a);
                }

            }
            @Override
            public void afterTextChanged(Editable s) {
                if(a<16.00f)
                {
                    a=80.00f;

                }







            }
        });
    }
}
